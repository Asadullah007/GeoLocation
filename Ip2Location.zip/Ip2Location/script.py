from ip2geotools.databases.noncommercial import DbIpCity
from urllib.request import urlopen
#import urllib2

print(urlopen('http://ip.42.pl/raw').read())

ip = urlopen('http://ip.42.pl/raw').read()


response = DbIpCity.get(ip, api_key="free")

print("\n") # new line

print("Your Region is : {0}".format(response.region))

print("\n")
print("********************")

print("Your Country is : {0}".format(response.country))

print("\n")
print("********************")

print("Your City is : {0}".format(response.city))

print("\n")
print("********************")

with open("info.txt","w") as myfile:
  data = str(response) # here convert response to string to write it in file
  myfile.write(data)